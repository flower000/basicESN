import numpy as np
import matplotlib.pyplot as plt
from numpy.linalg import inv    # multiplicative inverse for a matrix
import scipy
from scipy import signal
from scipy.signal import wiener
from numpy import array
from numpy import empty
from statsmodels.tsa.stattools import acf
from statsmodels.tsa.arima.model import ARIMA


class wienerpredictor:

    def __init__(self, coef, bias, varu, varv):
        self.coef = coef
        self.bias = bias
        self.varu = varu
        self.varv = varv

    def solve_yule_walker(self):
        """
        根据Yule-Walker方程求解自相关矩阵和互相关向量（包含AWGN）。

        :return:
        """
        p = len(self.coef)
        R = np.zeros(p + 1)
        r = np.zeros(p)
        # 计算均值校正后的自相关矩阵元素
        R[0] = self.varu / (1 - np.sum(np.array(self.coef) ** 2)) + self.bias ** 2

        for k in range(1, p + 1):
            R[k] = np.dot(self.coef[:k], R[:k][::-1])
        for k in range(1, p):
            r[k] = np.dot(self.coef[:k], R[1:k + 1][::-1])
        # 计算均值校正后的互相关向量第一个元素
        r[0] = R[0] + self.varv - np.dot(self.coef, R[1:])

        '''
        R = np.zeros(p + 1)
        r = np.zeros(p)
        R[0] = self.varu / (1 - np.sum(np.array(self.coef) ** 2))

        for k in range(1, p + 1):
            R[k] = np.dot(self.coef[:k], R[:k][::-1])
        r[0] = R[0] + self.varv  # 包含AWGN能量的r[0]
        for k in range(1, p):
            r[k] = np.dot(self.coef[:k], R[1:k + 1][::-1])
        '''

        return R, r

    def wiener_coef(self):
        """
        计算Wiener预测器的理论最优系数。

        :return:
        """
        p = len(self.coef)
        R, r = self.solve_yule_walker()
        R_matrix = scipy.linalg.toeplitz(R[:p])
        wiener_coef = np.linalg.solve(R_matrix, r)
        return wiener_coef

    def wiener_predict(self, signal, N, alpha):
        # signal_distorted: observed signal
        # N: length of signal_distorted
        # prec: N*prec points used for training
        # order: filter order
        # a varu varv: parameters of AR(1)

        p = len(self.coef)
        signal_filtered = np.zeros(int(np.ceil(N * (1 - alpha))))
        discretime = np.array([x for x in range(int(N * alpha), N)])

        wiener_coef = self.wiener_coef()

        for n in range(int(N * alpha), N):
            signal_filtered[n - int(N * alpha)] = np.dot(wiener_coef, signal[n - p + 1: n + 1])

        return signal_filtered, discretime


def autocorrelation_ar_p(a, n):
    """
    计算p阶自回归过程AR(p)的前n个自相关系数。

    :param a:  自回归系数列表 [a0, a1, ..., ap]，其中a0通常为0。
    :param n:  求解自相关系数的个数。
    :return:   自相关系数的列表。
    """
    p = len(a) - 1  # 自回归阶数
    if n <= p:
        raise ValueError("n must be greater than the order p of the AR process.")

    # 初始化自相关系数数组，前p+1个值
    rho = np.zeros(n)
    rho[0] = 1  # ρ(0) = 1

    # 计算前p个自相关系数
    for k in range(1, p+1):
        rho[k] = sum(a[j] * rho[k-j] for j in range(1, k+1))

    # 计算剩余的自相关系数
    for k in range(p+1, n):
        rho[k] = sum(a[j] * rho[k-j] for j in range(1, p+1))

    return rho


def Wiener_known(signal_distorted, N, prec, coef, bias, varu, varv):
    # signal_distorted: observed signal
    # N: length of signal_distorted
    # prec: N*prec points used for training
    # order: filter order
    # a varu varv: parameters of AR(1)

    # init
    signal_filtered = np.zeros(int(np.ceil(N * (1 - prec))))
    discretime = np.array([x for x in range(int(N * prec), N)])

    # calculate auto-correlation
    order = len(prec)
    rvv = np.zeros(order)
    rvv[0] = varv                               # AWGN

    # tau = np.array(list(range(0, order)))
    # tau = tau[:, np.newaxis]
    # rss = coef[0] ** tau / (1 - coef[0] ** 2) * varu        # known signal
    rho = autocorrelation_ar_p([0]+coef, order+1)     # auto variance
    rss = varu / (1 - np.sum(coef * rho[1:len(coef)+1])) * rho[:-1]      # Yule-Walker equation

    rxx = rss + rvv                             # observed signal
    rxx_toep = scipy.linalg.toeplitz(rxx)       # Toeplitz matrix

    # calculate cross-correlation
    rxs = rss

    # Wiener filtering
    w = np.dot(inv(rxx_toep), rxs)              # optimal coefficient

    for n in range(int(N * prec), N):
        signal_filtered[n - int(N * prec)] = np.dot(w, signal_distorted[n - order + 1: n + 1])

    return signal_filtered, discretime


def Wiener_unknown(signal_distorted, N, prec, order, varv):
    # signal_distorted: observed signal
    # N: length of signal_distorted
    # prec: N*prec points used for training
    # order: filter order
    # varv: AWGN variance

    if order > N * prec:
        print("Error in function Wiener_unknown: too large filter's order!\n")
        return -1, -1

    # init
    signal_filtered = np.zeros(int(np.ceil(N * (1 - prec))))
    discretime = np.array([x for x in range(int(N * prec), N)])

    # calculate auto-correlation
    rvv = np.zeros(order)
    rvv[0] = varv                               # AWGN

    rxx = np.zeros(order)                       # observed signal
    for k in range(0, order):
        rxx[k] = 1 / (N * prec - k) * np.dot(signal_distorted[0: int(N * prec - k)], signal_distorted[k: int(N * prec)])
    rxx_toep = scipy.linalg.toeplitz(rxx)       # Toeplitz matrix

    rss = rxx - rvv                             # known signal

    # calculate cross-correlation
    rxs = rss

    # Approximated Wiener filtering
    w = np.dot(inv(rxx_toep), rxs)              # optimal coefficient
    for n in range(int(N * prec), N):
        signal_filtered[n - int(N * prec)] = np.dot(w, signal_distorted[n - order + 1: n + 1])

    return signal_filtered, discretime


# Reference:
# https://github.com/hananabilabd/Weiner-Filter-Implementation/blob/master/WienerFilter.py
