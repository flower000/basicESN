import numpy as np
import matplotlib.pyplot as plt
from numpy.linalg import inv    # multiplicative inverse for a matrix
import scipy
from scipy import signal
from scipy.signal import wiener
from numpy import array
from numpy import empty
from statsmodels.tsa.stattools import acf
from statsmodels.tsa.arima.model import ARIMA


def autocorrelation_ar_p(a, n):
    """
    计算p阶自回归过程AR(p)的前n个自相关系数。

    :param a:  自回归系数列表 [a0, a1, ..., ap]，其中a0通常为0。
    :param n:  求解自相关系数的个数。
    :return:   自相关系数的列表。
    """
    p = len(a) - 1  # 自回归阶数
    if n <= p:
        raise ValueError("n must be greater than the order p of the AR process.")

    # 初始化自相关系数数组，前p+1个值
    rho = np.zeros(n)
    rho[0] = 1  # ρ(0) = 1

    # 计算前p个自相关系数
    for k in range(1, p+1):
        rho[k] = sum(a[j] * rho[k-j] for j in range(1, k+1))

    # 计算剩余的自相关系数
    for k in range(p+1, n):
        rho[k] = sum(a[j] * rho[k-j] for j in range(1, p+1))

    return rho


def compute_covariance_function_ar_p(coefficients, noise_variance, lags):
    """
    计算 AR(p) 过程的协方差函数。

    :param coefficients: AR(p) 模型的系数列表 [a0, a1, ..., ap]。
    :param noise_variance: 高斯白噪声的方差。
    :param lags: 要计算的最大时滞。
    :return: 从0到lags的协方差函数列表。
    """
    # 模拟 AR(p) 过程
    p = len(coefficients) - 1
    ar_params = np.r_[1, -np.array(coefficients[1:])]
    ma_params = np.array([1])
    arima_process = ARIMA(np.zeros(lags), order=(p, 0, 0), trend='n', exog=None).fit()
    acfs = acf(arima_process.resid, nlags=lags, fft=False)

    # 将自相关函数转换成协方差函数
    covariance_function = acfs[:lags+1] * noise_variance
    return covariance_function


def Wiener_known(signal_distorted, N, prec, order, coef, bias, varu, varv):
    # signal_distorted: observed signal
    # N: length of signal_distorted
    # prec: N*prec points used for training
    # order: filter order
    # a varu varv: parameters of AR(1)

    # init
    signal_filtered = np.zeros(int(np.ceil(N * (1 - prec))))
    discretime = np.array([x for x in range(int(N * prec), N)])

    # calculate auto-correlation
    rvv = np.zeros(order)
    rvv[0] = varv                               # AWGN

    # tau = np.array(list(range(0, order)))
    # tau = tau[:, np.newaxis]
    # rss = coef[0] ** tau / (1 - coef[0] ** 2) * varu        # known signal
    rho = autocorrelation_ar_p([0]+coef, order+1)     # auto variance
    rss = varu / (1 - np.sum(coef * rho[1:len(coef)+1])) * rho[:-1]      # Yule-Walker equation

    # rss = compute_covariance_function_ar_p([bias]+coef, varu, order)

    rxx = rss + rvv                             # observed signal
    rxx_toep = scipy.linalg.toeplitz(rxx)       # Toeplitz matrix

    # calculate cross-correlation
    rxs = rss

    # Wiener filtering
    w = np.dot(inv(rxx_toep), rxs)              # optimal coefficient
    for n in range(int(N * prec), N):
        signal_filtered[n - int(N * prec)] = np.dot(w, signal_distorted[n - order + 1: n + 1])

    return signal_filtered, discretime


def Wiener_unknown(signal_distorted, N, prec, order, varv):
    # signal_distorted: observed signal
    # N: length of signal_distorted
    # prec: N*prec points used for training
    # order: filter order
    # varv: AWGN variance

    if order > N * prec:
        print("Error in function Wiener_unknown: too large filter's order!\n")
        return -1, -1

    # init
    signal_filtered = np.zeros(int(np.ceil(N * (1 - prec))))
    discretime = np.array([x for x in range(int(N * prec), N)])

    # calculate auto-correlation
    rvv = np.zeros(order)
    rvv[0] = varv                               # AWGN

    rxx = np.zeros(order)                       # observed signal
    for k in range(0, order):
        rxx[k] = 1 / (N * prec - k) * np.dot(signal_distorted[0: int(N * prec - k)], signal_distorted[k: int(N * prec)])
    rxx_toep = scipy.linalg.toeplitz(rxx)       # Toeplitz matrix

    rss = rxx - rvv                             # known signal

    # calculate cross-correlation
    rxs = rss

    # Approximated Wiener filtering
    w = np.dot(inv(rxx_toep), rxs)              # optimal coefficient
    for n in range(int(N * prec), N):
        signal_filtered[n - int(N * prec)] = np.dot(w, signal_distorted[n - order + 1: n + 1])

    return signal_filtered, discretime


# Reference:
# https://github.com/hananabilabd/Weiner-Filter-Implementation/blob/master/WienerFilter.py
